package poly.com.controller.PS34126_Lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps34126Lab2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps34126Lab2Application.class, args);
	}

}
