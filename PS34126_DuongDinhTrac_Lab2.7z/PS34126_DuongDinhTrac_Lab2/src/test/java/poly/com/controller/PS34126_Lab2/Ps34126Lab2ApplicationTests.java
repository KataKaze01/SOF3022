package poly.com.controller.PS34126_Lab2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps34126Lab2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
