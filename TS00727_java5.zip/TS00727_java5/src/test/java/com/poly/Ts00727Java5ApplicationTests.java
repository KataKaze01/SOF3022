package com.poly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ts00727Java5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
