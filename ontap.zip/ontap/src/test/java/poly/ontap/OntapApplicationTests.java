package poly.ontap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OntapApplicationTests {

	@Test
	void contextLoads() {
	}

}
