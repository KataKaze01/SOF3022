package poly.edu.ontap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OntapApplication {
	public static void main(String[] args) {
		SpringApplication.run(OntapApplication.class, args);
	}
}