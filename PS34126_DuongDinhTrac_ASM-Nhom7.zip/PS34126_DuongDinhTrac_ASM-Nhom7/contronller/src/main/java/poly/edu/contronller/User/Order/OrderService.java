package poly.edu.contronller.User.Order;

public interface OrderService {
    void createOrder(Integer userId);
}
