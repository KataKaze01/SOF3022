package poly.edu.contronller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContronllerApplication {
	public static void main(String[] args) {
		SpringApplication.run(ContronllerApplication.class, args);
	}
}
